<?php 
session_start();

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','pvs_cms');

define('URL', 'http://pvs-cms.com/admin/');
define('ROOT', realpath(dirname(__FILE__) . '/../') . '/admin/');
define('FRONTEND_ROOT',realpath(dirname(__FILE__) . '/../'));
define('FRONTEND_URL', rtrim('http://pvs-cms.com/','/')); 
define('LIBS','libraries/');
define('ACTIVE_THEME','default');
define('PATH',__DIR__.'/../assets/');

define('PATCH_SOURCE', 'http://cmsupdates.kb.sg/cms-patcher/'); //online-patcher

?>