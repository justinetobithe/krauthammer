# getAttribute

```php
getAttribute ( string $name ) : mixed
```

| Parameter | Description
| --------- | -----------
| `name`    | Attribute name.

Returns the value for the attribute `$name`.