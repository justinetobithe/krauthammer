# loadFile

```php
loadFile (...)
```

This function is a wrapper for [`load_file`](#load_file)